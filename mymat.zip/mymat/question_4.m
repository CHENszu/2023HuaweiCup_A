clear
clc
% 产生一个初步猜测
initial_guess = [0.1, 0.1];

% 使用fsolve求解方程
options = optimoptions('fsolve', 'Display', 'iter');
[solution, fval, exitflag, output] = fsolve(@equations, initial_guess, options);
solution = real(solution);
tau_solution = solution(1);
p_solution = solution(2);

% 计算中间变量
N = 2;
p_tr = 1-(1-tau_solution)^N;
p_s = N*tau_solution*(1-tau_solution)^(N-1)/p_tr;
p_c = 1-p_tr;
fprintf("tau_solution = %.4f\n", tau_solution);
fprintf("p_tr = %.4f\n", p_tr);
fprintf("p_s = %.4f\n", p_s);
% T_e = slotTime;
% T_s = phyHeader+macHeader+E_p/rate+SIFS+ACK+DIFS;
% T_c = phyHeader+macHeader+E_p/rate+DIFS+ACKTimeout;

% 根据给定的p计算b00
function b00 = get_b00(p, r, m, CW_min)
    if r <= m
        b00 = (2*(1-p)*(1-2*p))/((1-2*p)*(1-p^(r+1))+CW_min*(1-p)*(1-(2*p)^(r+1)));
    else
        b00 = (2*(1-p)*(1-2*p))/(CW_min*(1-(2*p)^(m+1))^(1-p)+(1-2*p)*(1-p^(r+1))+CW_min*2^m*p^(m+1)*(1-p^(r-m)*(1-2*p)));
    end
end

% 方程组函数
function F = equations(vars)
    tau = vars(1);
    p = vars(2);
    % 参数设置
    r = 32;
    m = 6;
    CW_min = 16;
    N = 2;
    b00 = get_b00(p, r, m, CW_min);
    % 系统方程
    F(1) = tau - b00 * (1 - p^(r+1)) / (1 - p);
    F(2) = p - (1 - (1 - tau)^(N-1));
%     F(1) = tau-2*p;
%     F(2) = p - tau^2;
end