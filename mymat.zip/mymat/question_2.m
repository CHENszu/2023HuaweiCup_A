clear
clc
% 参数设置
N=2;
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
rate = 275.3e6;
macHeader = 30*8/rate;
ACKTimeout = 65e-6;
payload = 1500*8;
CW_min = 16;
CW_max = 1024;
r = 32;% 最大重传次数
m = log2(CW_max / CW_min);% 最大退避阶数
tau_solution = 0.0961182605;
p_solution = 0.0961182605;
T_s = phyHeader+macHeader+payload/rate+SIFS+ACK+DIFS;
T_c = T_s;
% 1-模型一计算
% 计算中间变量
p_tr = 1-(1-tau_solution)^N;
p_c = 1 - ((1 - tau_solution)^N + N * tau_solution * (1 - tau_solution)^(N-1));
p_c = p_c/p_tr;
p_s = N*tau_solution*(1-tau_solution)^(N-1)/p_tr;
E_p = payload;
T_e = slotTime;
% 计算吞吐量
S = (p_tr*p_s*E_p+2*p_tr*p_c*E_p)/((1-p_tr)*T_e+p_tr*p_s*T_s+(1-p_s)*p_tr*T_c);
% 2-模型二计算 
P_idle = (1-tau_solution)^N;
P_S = N*tau_solution*(1-tau_solution)^(N-1);
SS = (P_S*payload+2*P_idle*payload)/(slotTime*P_idle+P_S*T_s+(1-P_S-P_idle)*T_c);