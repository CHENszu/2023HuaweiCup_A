clear
clc
% 导入求得的数据
loaded_data = load('solutions.mat');
solutions = loaded_data.solutions;
% 参数设置
N=2;
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
macHeader = 30*8;
ACKTimeout = 65e-6;
payload = 1500*8;
p_e = 0.1;
CW_min = [16,32,16,16,32,16,16];
CW_max = 1024;
m = log2(CW_max./CW_min); %最大退避次数
r = [6,5,32,6,5,32,32];
rate = [286.8e6,286.8e6,286.8e6,158.4e6,158.4e6,158.4e6,455.8e6];
tau1_solution = solutions(:,1);
p = solutions(:,2);
tau2_solution = solutions(:,3);
S = []; %存储计算的吞吐量
S1 = [];
for i = 1:7
    % 相关时间计算
    t0 = phyHeader+(macHeader+payload)/rate(i);
    T_s = t0+SIFS+ACK+DIFS;
    %T_in_hid = 0.5*(phyHeader+(macHeader+payload)/rate(i));
    T_in_hid = 0.5*phyHeader;
    T_hidden = T_in_hid+phyHeader+(macHeader+payload)/rate(i)+DIFS+ACKTimeout;
    T_in_cov = 0.5*slotTime;
    T_covered = T_in_cov+t0+ACKTimeout+DIFS;
    T_c = 0.5*T_covered+0.5*T_hidden;
    T_c1 = phyHeader+(macHeader+payload)/rate(i)+DIFS+ACKTimeout;
    % 一般计算
    p_iddle = (1-tau1_solution(i))^2; % 空闲时间
    ps = 2*tau1_solution(i)*(1-tau2_solution(i)); % 成功传输概率
    pc = 1-p_iddle-ps;
    s1 = 2*0.9*ps*payload/(slotTime*p_iddle+ps*T_s+pc*T_c);
    S1 = [S1;s1];
    % 理想信道计算
    p_tr = 1-(1-tau1_solution(i))^2;
    p_s = 2*tau1_solution(i)*(1-tau2_solution(i))/p_tr;
    s = 2*p_tr*p_s*0.9*payload/((1-p_tr)*slotTime+p_tr*p_s*T_s+(1-p_s)*p_tr*T_c);
    S = [S;s];
end
