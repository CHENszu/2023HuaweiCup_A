clear
clc
% 参数设置
loaded_data = load('solutions.mat');
solutions = loaded_data.solutions;
N=2;
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
macHeader = 30*8;
ACKTimeout = 65e-6;
payload = 1500*8;
CW_min = [16,32,16,16,32,16];
CW_max = 1024;
r = [6,5,32,6,5,32];% 最大重传次数
m = log2(CW_max ./ CW_min);% 最大退避阶数
rate = [286.8e6,286.8e6,286.8e6,158.4e6,158.4e6,158.4e6,455.8e6];

% 针对整个系统计算相关概率
p_tr1 = [0.1983,0.1108,0.1830,0.1983,0.1108,0.1830,0.1830];
p_idle1 = 1-p_tr1; %空闲时间
p_s1 = [0.9448,0.9706,0.9495,0.9448,0.9706,0.9495,0.9495];
p_ss1 = p_tr1.*p_s1; %成功发送
p_c1 = 1-p_idle1-p_ss1; %冲突概率
tau1 = solutions(:,1)';
p = solutions(:,2)';
p_idle2 = (1-tau1).^2;
p_s2 = 2*tau1.*(1-p);
p_c2 = 1-p_idle2-p_s2;
% 计算相关时间
T_s = phyHeader+(macHeader+payload)./rate+SIFS+ACK+DIFS;
T_c = 4/3*phyHeader+(macHeader+payload)./rate+DIFS+ACKTimeout;
P = 2*p_ss1.*p_idle2+p_s2.*p_idle1;
P_i = p_idle1.*p_idle1.*p_idle2;
S0 = (payload*P)./(T_s.*P+T_c.*(1-P_i-P)+slotTime*P_i);

tau1 = [0.1046,0.0570,0.0961,0.1046,0.0570,0.0961,0.0961];
tau21 = [0.0930,0.0536,0.0818,0.0930,0.0536,0.0818,0.0818];
tau22 = [0.1807,0.1057,0.1589,0.1807,0.1057,0.1589,0.1589];
p_idle2 = 1-tau21;
p_s2 = 2*tau1.*(1-tau22);
p_c2 = 1-p_idle2-p_s2;
S1 = (payload*p_ss1)./(T_s.*p_ss1+T_c.*p_c1+slotTime*p_idle1);
S2 = (payload*p_s2)./(T_s.*p_s2+T_c.*p_c2+slotTime*p_idle2);
S = 2/3*S1'+1/3*S2';
