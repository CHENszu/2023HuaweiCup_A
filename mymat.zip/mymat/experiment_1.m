clear
clc
tic
% 基本参数设置
DIFS = 43e-6;
CW_min = 16;
CW_max = 1024;
r = 32;
m = 6;
SIFS = 16e-6;
phyHeader = 13.6e-6;
macHeader = 30*8/455.8e6;
payload = 1500*8/455.8e6;
slotTime = 9e-6;%最小时间间隔
ACKTimeout = 65e-6;
ACK = 32e-6; 
t_c = phyHeader+macHeader+payload+ACKTimeout;
t_s = phyHeader+macHeader+payload+SIFS+ACK;
timesall = 0;
s_plot = zeros(1001,2);
repeat = 1;% 重复实验,在统计里面最好添加，此时不添加也无妨（方便绘图）
for i = 1:repeat 
    t = 0;
    T = 1000;
    m0 = 0; % 控制最大退避次数
    flag = 0; % 控制哪个AP节点回退
    times = 0; % 成功传输次数
    while t<T
        t = t+DIFS;
        if flag == 0
            BO1 = randi([0, CW_min-1]);
            BO2 = randi([0, CW_min-1]);
        elseif flag == 1
            BO1 = randi([0, CW_min-1]);
        elseif flag == 2
            BO2 = randi([0, CW_min-1]);
        end
        if BO1 == BO2 %冲突
            flag = 0;
            t = t+BO1*slotTime;
            t = t+t_c;
            m0 = m0+1;
            if CW_min<CW_max
                CW_min = CW_min*2;
            end
        else % 成功传输
            if BO1>BO2
                s_plot(ceil(t),2) = s_plot(ceil(t),2)+1;
            else
                s_plot(ceil(t),1) = s_plot(ceil(t),1)+1;
            end
            times = times+1; %信道成功传输次数
            CW_min = 16;
            m0 = 0;
            BO_temp = min(BO1,BO2);
            t = t+BO_temp*slotTime;
            t = t+t_s;
            if BO1>BO2
                BO1 = BO1-BO2;
                flag = 2;
            else
                BO2 = BO2-BO1;
                flag = 1;
            end
        end
        if m0>=r %失败次数达到最大
            CW_min = 16;
            flag = 0;
            m0 = 0;
        end
    end
    timesall = timesall+times;
end
times_average = timesall/repeat;
S = payload*times_average/T*455.8e6;
elapsedTime = toc;
disp(['程序执行时间为：' num2str(elapsedTime) '秒']);
% 绘图代码
s_plot =  payload*s_plot/1000*455.8e6;
x = 1:1000;
plot(x,s_plot(1:1000,1))
hold on
plot(x,s_plot(1:1000,2))
hold on
plot(x,s_plot(1:1000,1)+s_plot(1:1000,2))
xlabel('时间/T')
ylabel('吞吐量/bps')
legend('AP1','AP2','汇总')