clear
clc
N = 2;
CW_max = 1024;
CW_min1 = [16,32,16,16,32,16,16];
m1 = log2(CW_max./CW_min1);
r1 = [6,5,32,6,5,32,32];
rate1 = [286.8e6,286.8e6,286.8e6,158.4e6,158.4e6,158.4e6,455.8e6];
v1 = (13.6e-6+12240./rate1)/9e-6;
% 初步猜测值
initial_guess = [0.1, 0.1, 0.1];
options = optimoptions('fsolve', 'Display', 'off');
% 主脚本中，为每组参数单独调用fsolve
solutions = zeros(length(CW_min1), length(initial_guess));
for i = 1:length(CW_min1)
    [current_solution,~,~,~] = fsolve(@(vars)equations(vars, N, CW_min1(i), m1(i), r1(i), rate1(i), v1(i)), initial_guess, options);
    solutions(i,:) = real(current_solution);
end
disp(solutions);
save('solutions.mat', 'solutions');
function b00 = get_b00(p, r, m, CW_min)
    if r <= m
        b00 = (2*(1-p)*(1-2*p))/((1-2*p)*(1-p^(r+1))+CW_min*p*(1-(2*p)^(r+1)));
    else
        b00 = (2*(1-p)*(1-2*p))/(CW_min*(1-(2*p)^(m+1))+(1-2*p)*(1-p^(r+1))+CW_min*2^m*p^(m+1)*(1-p^(r-m)*(1-2*p)));
    end
end

function F = equations(vars, N, CW_min, m, r, ~, v)
    tau = vars(1);
    p = vars(2);
    tau2 = vars(3);
    b00 = get_b00(p, r, m, CW_min);

    % 方程，这次我们不再累加，而是针对特定的变量求值
    F(1) = tau - b00 * (1 - p^(r+1)) / (1 - p);
    F(2) = p - (1 - (1 - tau)^(N-2)*(1 - tau2)^(N-1));
    F(3) = tau2 - b00*((v+1)*(1-p^(r+1))/(1-p)-(v*(v+1)/(2*CW_min))*(1-(p/2)^(r+1))/(1-p/2));
    F = F(:); % 确保F总是列向量
end