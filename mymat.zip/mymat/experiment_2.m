clear
clc
tic
% 参数设置
N=2;
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
rate = 275.3e6;
macHeader = 30*8/rate;
ACKTimeout = 65e-6;
payload = 1500*8;
CW_min = 16;
CW_max = 1024;
r = 32;% 最大重传次数
m = log2(CW_max / CW_min);% 最大退避阶数
t_s = phyHeader+macHeader+payload/rate+SIFS+ACK;
t_c = t_s;
timesall = 0;
s_plot = zeros(1001,2);
for i = 1:1 %重复实验
    t = 0;
    T = 1000;
    times = 0;
    flag = 0;
    while t<T
        t = t+DIFS;
        if flag == 0
            BO1 = randi([0, CW_min-1]);
            BO2 = randi([0, CW_min-1]);
        elseif flag == 1
            BO1 = randi([0, CW_min-1]);
        elseif flag == 2
            BO2 = randi([0, CW_min-1]);
        end
        if BO1 == BO2 %冲突
            t = t+BO1*slotTime;
            t = t+t_s;
            times = times+2;
            s_plot(ceil(t),:) = s_plot(ceil(t),:)+1;
            flag = 0;
        else % 成功传输
            if BO1>BO2
                s_plot(ceil(t),2) = s_plot(ceil(t),2)+1;
            else
                s_plot(ceil(t),1) = s_plot(ceil(t),1)+1;
            end
            times = times+1; %信道成功传输次数
            BO_temp = min(BO1,BO2);
            t = t+BO_temp*slotTime;
            t = t+t_s;
            if BO1>BO2
                BO1 = BO1-BO2;
                flag = 2;
            else
                BO2 = BO2-BO1;
                flag = 1;
            end
        end
    end
    timesall = timesall+times;
end
times_average = timesall/100;
S = payload*times_average/T;
elapsedTime = toc;
disp(['程序执行时间为：' num2str(elapsedTime) '秒']);
s_plot =  payload*s_plot/1000;
x = 1:1000;
plot(x,s_plot(1:1000,1))
hold on
plot(x,s_plot(1:1000,2))
hold on
plot(x,s_plot(1:1000,1)+s_plot(1:1000,2))
xlabel('时间/T')
ylabel('吞吐量/bps')
legend('AP1','AP2','汇总')