clear
clc
tic
% 参数设置
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
macHeader = 30*8;
ACKTimeout = 65e-6;
payload = 1500*8;
CW_min = [16,32,16,16,32,16,16];
CW_max = 1024;
m = log2(CW_max./CW_min); %最大退避次数
r = [6,5,32,6,5,32,32]; %最大重传次数
rate = [286.8e6,286.8e6,286.8e6,158.4e6,158.4e6,158.4e6,455.8e6];
T = 1000;
S = [];
S_plot = zeros(7,1001,4);
for i = 1:7
    T_s = phyHeader+macHeader/rate(i)+payload/rate(i)+SIFS+ACK;
    T_load = phyHeader+macHeader/rate(i)+payload/rate(i);% 发包时长
    T_c = phyHeader+macHeader/rate(i)+payload/rate(i)+ACKTimeout;
    BO_s = T_s/slotTime;
    BO_c = T_c/slotTime;
    w0 = [CW_min(i),CW_min(i),CW_min(i)];
    m0 = [0,0,0]; % 控制CW_min是否继续×2
    r0 = [0,0,0];
    times = zeros(4,1); % 记录成功次数
    BO = [0,0,0];
    t = 0;
    for j = 1:3 % 初始化系统
        BO(j) = getBO(w0(j));
    end
    while t<T % 开始传输
        t = t +DIFS;
        % 1第一种情况，都处在回退状态
        %if isequal(flag, [0,0,0])
        minValue = min(BO);
        minPos = find(BO == minValue);
        switch length(minPos)
            case 1 
                % 最小元素在一个位置，如[1,2,3]
                if minPos==1 %1.1 AP1最先回退完毕
                    % AP2暂停回退，故仅需要考虑AP3
                     t = t + slotTime*BO(1);
                    %secondMinPos = find(BO == min(BO(BO > minValue)));
                    %if secondMinPos==3 %1.1.1
                    t_temp = (BO(3)-BO(1))*slotTime;
                    if t_temp>=T_s
                        times(1) = times(1)+1;
                        S_plot(i,ceil(t),1) = S_plot(i,ceil(t),1)+1;
                        t=t+T_s;
                        BO(3)=BO(3)-BO(1)-BO_s;
                        [r0,m0,w0,BO] = update_s(1,r0,m0,w0,CW_min,BO,i);
                    elseif t_temp>=phyHeader
                        times(1)=times(1)+1;
                        S_plot(i,ceil(t),1) = S_plot(i,ceil(t),1)+1;
                        t=t+t_temp;
                        [r0,m0,w0,BO] = update_s(1,r0,m0,w0,CW_min,BO,i);
                        BO(3)=0;
                        BO(1) = BO(1)+(T_s-t_temp)/slotTime;
                    else
                        t = t+T_c;
                        [r0,m0,w0,BO] = update_c(1,r0,r,m0,m,w0,CW_min,BO,i);
                        [r0,m0,w0,BO] = update_c(3,r0,r,m0,m,w0,CW_min,BO,i);
                        BO(3) = BO(3)+t_temp/slotTime;
                    end
                elseif minPos==2
                    BO(1)=BO(1)-BO(2);
                    BO(3)=BO(3)-BO(2);
                    times(2)=times(2)+1;
                    S_plot(i,ceil(t),2) = S_plot(i,ceil(t),2)+1;
                    t=t+BO(2)*slotTime+T_s;
                    [r0,m0,w0,BO] = update_s(2,r0,m0,w0,CW_min,BO,i);
                else
                    t=t+slotTime*BO(3);
                    t_temp = (BO(1)-BO(3))*slotTime;
                    if t_temp>=T_s
                        times(3) = times(3)+1;
                        S_plot(i,ceil(t),3) = S_plot(i,ceil(t),3)+1;
                        t=t+T_s;
                        BO(1)=BO(1)-BO(3)-BO_s;
                        [r0,m0,w0,BO] = update_s(3,r0,m0,w0,CW_min,BO,i);
                    elseif t_temp>=phyHeader
                        times(3)=times(3)+1;
                        S_plot(i,ceil(t),3) = S_plot(i,ceil(t),3)+1;
                        t=t+t_temp;
                        [r0,m0,w0,BO] = update_s(3,r0,m0,w0,CW_min,BO,i);
                        BO(1)=0;
                        BO(3) = BO(3)+(T_s-t_temp)/slotTime;
                    else
                        t = t+T_c;
                        [r0,m0,w0,BO] = update_c(1,r0,r,m0,m,w0,CW_min,BO,i);
                        [r0,m0,w0,BO] = update_c(3,r0,r,m0,m,w0,CW_min,BO,i);
                        BO(1) = BO(1)+t_temp/slotTime;
                    end
                end

            case 2
                % 最小元素在两个位置，例如BO=[1,1,2]
               if isequal(minPos,[1,2])
                    t = t+BO(1)*slotTime;
                    BO(3)=BO(3)-BO(1);
                    t=t+T_c;
                    [r0,m0,w0,BO] = update_c(1,r0,r,m0,m,w0,CW_min,BO,i);
                    [r0,m0,w0,BO] = update_c(2,r0,r,m0,m,w0,CW_min,BO,i);
               elseif isequal(minPos,[2,3])
                    t = t+BO(2)*slotTime;
                    BO(1)=BO(1)-BO(3);
                    t=t+T_c;
                    [r0,m0,w0,BO] = update_c(2,r0,r,m0,m,w0,CW_min,BO,i);
                    [r0,m0,w0,BO] = update_c(3,r0,r,m0,m,w0,CW_min,BO,i);
               else
                   t=t+BO(1)*slotTime;
                   BO(2)=BO(2)-BO(1);
                   t = t+T_c;
                   [r0,m0,w0,BO] = update_c(1,r0,r,m0,m,w0,CW_min,BO,i);
                   [r0,m0,w0,BO] = update_c(3,r0,r,m0,m,w0,CW_min,BO,i);
               end
            case 3
                % 最小元素在所有位置，例如BO=[1,1,1]
                t=t+BO(1)*slotTime+T_c;
                for j=1:3
                    [r0,m0,w0,BO] = update_c(j,r0,r,m0,m,w0,CW_min,BO,i);
                end
        end
    end % t<T
    times(4)=sum(times(1:3));
    S_temp = payload*sum(times(4))/T;
    S = [S;S_temp];
end %i=1:7
% 绘图
titles = {'(32,5,286.8)', '(16,32,286.8)', ...
    '(16,6,158.4)', '(32,5,158.4)', '(16,32,158.4)', '(16,32,455.8)'};
x = 1:1000;
S_plot = S_plot*payload/1000;
for i=2:7
    subplot(3,2,i-1)
    plot(x,S_plot(i,1:1000,1))
    hold on
    plot(x,S_plot(i,1:1000,2))
    hold on
    plot(x,S_plot(i,1:1000,3))
    hold on
    plot(x,S_plot(i,1:1000,1)+S_plot(i,1:1000,2)+S_plot(i,1:1000,3))
    xlabel('时间/T')
    ylabel('吞吐量/bps')
    title(titles(i-1));
    legend('AP1','AP2','AP3','汇总')
end
% fun1决定回退随机数函数
function BO = getBO(w0)
        BO = randi([0, w0-1]);
end

% fun2碰撞时参数变换的函数
function [r0,m0,w0,BO] = update_c(k,r0,r,m0,m,w0,CW_min,BO,i)
    r0(k)  = r0(k) + 1;
    if r0(k) > r(i) %超过最大重传次数
        r0(k) = 0;
        m0(k) = 0;
        w0(k) = CW_min(i);
        BO(k) = getBO(w0(k));
    else % 还传这个数据
        if m0(k) < m(i)  % 竞争窗口现在是否改变
            m0(k) = m0(k) +1;
            w0(k) = 2*w0(k);
            BO(k) = getBO(w0(k));
        else
            m0(k) = m0(k) +1;
            BO(k) = getBO(w0(k));
        end
    end
end

% fun3成功传输后参数变换的函数
function [r0,m0,w0,BO] = update_s(k,r0,m0,w0,CW_min,BO,i)
    r0(k) = 0;
    m0(k) = 0;
    w0(k) = CW_min(i);
    BO(k) = getBO(w0(k));
end