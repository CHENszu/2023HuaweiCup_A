clear
clc
% 参数设置
N=2;
slotTime = 9e-6; %间隙长度
SIFS = 16e-6; %成功传输等待时间
DIFS = 43e-6; %帧间距
ACK = 32e-6; 
phyHeader = 13.6e-6;
rate = 455.8e6;
macHeader = 30*8/rate;
ACKTimeout = 65e-6;
payload = 1500*8;
CW_min = 16;
CW_max = 1024;
r = 32;% 最大重传次数
m = log2(CW_max / CW_min);% 最大退避阶数

% 产生一个初步猜测
initial_guess = [0.5, 0.5];

% 使用fsolve求解方程
options = optimoptions('fsolve', 'Display', 'iter');
[solution, fval, exitflag, output] = fsolve(@equations, initial_guess, options);
solution = real(solution);
tau_solution = solution(1);
p_solution = solution(2);
%fprintf("tau_solution = %.10f\n", tau_solution);
%fprintf("p_solution = %.10f\n", p_solution);

% 1-转化为信道概率
% 计算中间变量
p_tr = 1-(1-tau_solution)^N;
p_s = N*tau_solution*(1-tau_solution)^(N-1)/p_tr;
E_p = payload;
T_e = slotTime;
T_s = phyHeader+macHeader+E_p/rate+SIFS+ACK+DIFS;
T_c = phyHeader+macHeader+E_p/rate+DIFS+ACKTimeout;
% 计算吞吐量
S = p_tr*p_s*E_p/((1-p_tr)*T_e+p_tr*p_s*T_s+(1-p_s)*p_tr*T_c);

% 2-直接计算 
P_idle = (1-tau_solution)^N;
P_S = N*tau_solution*(1-tau_solution)^(N-1);
SS = P_S*payload/(slotTime*P_idle+P_S*T_s+(1-P_S-P_idle)*T_c);
% 根据给定的p计算b00
function b00 = get_b00(p, r, m, CW_min)
    if r <= m
        b00 = (2*(1-p)*(1-2*p))/((1-2*p)*(1-p^(r+1))+CW_min*(1-p)*(1-(2*p)^(r+1)));
    else
        b00 = (2*(1-p)*(1-2*p))/(CW_min*(1-(2*p)^(m+1))^(1-p)+(1-2*p)*(1-p^(r+1))+CW_min*2^m*p^(m+1)*(1-p^(r-m)*(1-2*p)));
    end
end

% 方程组函数
function F = equations(vars)
    tau = vars(1);
    p = vars(2);
    % 参数设置
    r = 32;
    m = 6;
    CW_min = 16;
    N = 2;
    b00 = get_b00(p, r, m, CW_min);
    % 系统方程
    F(1) = tau - b00 * (1 - p^(r+1)) / (1 - p);
    F(2) = p - (1 - (1 - tau)^(N-1));
%     F(1) = tau-2*p;
%     F(2) = p - tau^2;
end